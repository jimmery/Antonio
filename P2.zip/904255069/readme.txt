We did this project by peer programming. Since this project was
relatively simplistic, there is not much else to mention for this
part. We use all the functions that were given to us, to the best
of our ability. 
